﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace DNS
{
    internal class DataBase
    {
        public static SqlConnection SqlConnection()
        {
            return new SqlConnection(@"Data Source=DESKTOP-8T8UFTU; Initial Catalog=DNS; Integrated Security=True");
        }

        public static void toDB(string query)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, SqlConnection());
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        public static DataTable fromDB(string query)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, SqlConnection());
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);
                DataTable dataTable = dataSet.Tables[0];
                return dataTable;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return new DataTable();
            }
        }
        public static void ImageToDB(string query, byte[] image)
        {
            try
            {
                SqlCommand _command = new SqlCommand(query, SqlConnection());
                _command.Parameters.Add("@ImageData", SqlDbType.Image, 1000000);
                _command.Parameters["@ImageData"].Value = image;

                _command.Connection.Open();
                _command.ExecuteNonQuery();
                _command.Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public static Image ImageFromByte(byte[] data)
        {
            try
            {
                MemoryStream _ms = new MemoryStream(data);
                Image _image = Image.FromStream(_ms);
                return _image;
            }
            catch
            {
                return Properties.Resources.NoPhoto;
            }
            
        }
    }
}
