﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xceed.Document.NET;
using Xceed.Words.NET;
using System.IO;

namespace DNS.UserComponents
{
    public partial class DeliveriesControl : UserControl
    {
        #region border
        //Fields
        private int borderSize = 0;
        private int borderRadius = 0;
        private Color borderColor = Color.PaleVioletRed;

        public int BorderSize
        {
            get { return borderSize; }
            set
            {
                borderSize = value;
                this.Invalidate();
            }
        }
        public int BorderRadius
        {
            get { return borderRadius; }
            set
            {
                borderRadius = value;
                this.Invalidate();
            }
        }
        public Color BorderColor
        {
            get { return borderColor; }
            set
            {
                borderColor = value;
                this.Invalidate();
            }
        }

        private GraphicsPath GetFigurePath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            float curveSize = radius * 2F;

            path.StartFigure();
            path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90);
            path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90);
            path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90);
            path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);


            Rectangle rectSurface = this.ClientRectangle;
            Rectangle rectBorder = Rectangle.Inflate(rectSurface, -borderSize, -borderSize);
            int smoothSize = 2;
            if (borderSize > 0)
                smoothSize = borderSize;

            if (borderRadius > 2) //Rounded button
            {
                using (GraphicsPath pathSurface = GetFigurePath(rectSurface, borderRadius))
                using (GraphicsPath pathBorder = GetFigurePath(rectBorder, borderRadius - borderSize))
                using (Pen penSurface = new Pen(this.Parent.BackColor, smoothSize))
                using (Pen penBorder = new Pen(borderColor, borderSize))
                {
                    pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    //Button surface
                    this.Region = new Region(pathSurface);
                    //Draw surface border for HD result
                    pevent.Graphics.DrawPath(penSurface, pathSurface);

                    //Button border                    
                    if (borderSize >= 1)
                        //Draw control border
                        pevent.Graphics.DrawPath(penBorder, pathBorder);
                }
            }
            else //Normal button
            {
                pevent.Graphics.SmoothingMode = SmoothingMode.None;
                //Button surface
                this.Region = new Region(rectSurface);
                //Button border
                if (borderSize >= 1)
                {
                    using (Pen penBorder = new Pen(borderColor, borderSize))
                    {
                        penBorder.Alignment = PenAlignment.Inset;
                        pevent.Graphics.DrawRectangle(penBorder, 0, 0, this.Width - 1, this.Height - 1);
                    }
                }
            }
        }
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            this.Parent.BackColorChanged += new EventHandler(Container_BackColorChanged);
        }

        private void Container_BackColorChanged(object sender, EventArgs e)
        {
            this.Invalidate();
        }
        private void Button_Resize(object sender, EventArgs e)
        {
            if (borderRadius > this.Height)
                borderRadius = this.Height;
        }
        #endregion

        public int deliveryId { get; set; } // Добавляем свойство для хранения ID поставки
        public string userRole = "Пользователь";

        public DeliveriesControl()
        {
            InitializeComponent();
        }

        private void DeliveriesControl_Load(object sender, EventArgs e)
        {
            if (userRole == "Администратор")
            {
                BTDelete.Visible = true;
            }
            else
            {
                BTDelete.Visible = false;
            }

            Lid.Text = deliveryId.ToString();
            DataTable _table = DataBase.fromDB($@"select products.name as product, description, count, delivery_date, suppliers.name as supplier, received_by, img 
            from suppliers inner join deliveries on deliveries.supplier_id = suppliers.id inner join products on deliveries.products_id = products.id 
            where deliveries.id = '{Lid.Text}'");

            LNameProduct.Text = _table.Rows[0]["product"].ToString();
            LDescProduct.Text = _table.Rows[0]["description"].ToString();

            LCount.Text = Convert.ToInt32(_table.Rows[0]["count"]).ToString();
            DataPostavki.Text = _table.Rows[0]["delivery_date"].ToString();

            Postavshik.Text = _table.Rows[0]["supplier"].ToString();
            PrinyalPostavku.Text = _table.Rows[0]["received_by"].ToString();

            if (_table.Rows[0]["img"].ToString() == "")
                pictureBox1.Image = Properties.Resources.NoPhoto;
            else
                pictureBox1.Image = DataBase.ImageFromByte((Byte[])_table.Rows[0]["img"]);
        }

        private void ButtonTexDok_Click(object sender, EventArgs e)
        {
            try
            {
                // Укажите путь к рабочему столу
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, $"ПриходнаяНакладная_{deliveryId}.docx");

                DataTable deliveryData = DataBase.fromDB($"SELECT * FROM [deliveries] WHERE [id] = {deliveryId}");

                if (deliveryData != null && deliveryData.Rows.Count > 0)
                {
                    // Создание документа
                    var doc = DocX.Create(filePath);

                    // Добавление заголовка
                    doc.InsertParagraph("Приходная накладная № " + deliveryData.Rows[0]["id"])
                        .FontSize(20)
                        .Bold()
                        .Alignment = Alignment.center;

                    // Добавление информации о поставщике
                    int supplierId = Convert.ToInt32(deliveryData.Rows[0]["supplier_id"]);
                    DataTable supplierData = DataBase.fromDB($"SELECT * FROM [suppliers] WHERE [id] = {supplierId}");

                    if (supplierData != null && supplierData.Rows.Count > 0)
                    {
                        doc.InsertParagraph("Поставщик: " + supplierData.Rows[0]["name"])
                            .FontSize(12);
                        doc.InsertParagraph("Контактное лицо: " + supplierData.Rows[0]["contact_person"])
                            .FontSize(12);
                        doc.InsertParagraph("Телефон: " + supplierData.Rows[0]["phone"])
                            .FontSize(12);
                        doc.InsertParagraph("Email: " + supplierData.Rows[0]["email"])
                            .FontSize(12);
                        doc.InsertParagraph("Адрес: " + supplierData.Rows[0]["address"])
                            .FontSize(12);
                    }

                    doc.InsertParagraph("Дата поставки: " + Convert.ToDateTime(deliveryData.Rows[0]["delivery_date"]).ToString("dd.MM.yyyy"))
                        .FontSize(12);
                    doc.InsertParagraph("Принято: " + deliveryData.Rows[0]["received_by"])
                        .FontSize(12);
                    doc.InsertParagraph("Примечания: " + deliveryData.Rows[0]["remarks"])
                        .FontSize(12);

                    // Добавление таблицы
                    Table t = doc.AddTable(2, 5); // Простая таблица с одной строкой данных
                    t.Design = TableDesign.TableGrid;

                    // Заполнение заголовков столбцов
                    t.Rows[0].Cells[0].Paragraphs[0].Append("№ п.п.");
                    t.Rows[0].Cells[1].Paragraphs[0].Append("Наименование");
                    t.Rows[0].Cells[2].Paragraphs[0].Append("Ед. изм.");
                    t.Rows[0].Cells[3].Paragraphs[0].Append("Кол-во");
                    t.Rows[0].Cells[4].Paragraphs[0].Append("Цена");

                    // Получение данных о продукте
                    int productId = Convert.ToInt32(deliveryData.Rows[0]["products_id"]);
                    DataTable productData = DataBase.fromDB($"SELECT * FROM [products] WHERE [id] = {productId}");

                    if (productData != null && productData.Rows.Count > 0)
                    {
                        // Заполнение строки данными
                        t.Rows[1].Cells[0].Paragraphs[0].Append("1");
                        t.Rows[1].Cells[1].Paragraphs[0].Append(productData.Rows[0]["name"].ToString());
                        t.Rows[1].Cells[2].Paragraphs[0].Append("шт"); // Укажите единицу измерения, если она есть
                        t.Rows[1].Cells[3].Paragraphs[0].Append(deliveryData.Rows[0]["count"].ToString());
                        t.Rows[1].Cells[4].Paragraphs[0].Append(productData.Rows[0]["price"].ToString());
                    }

                    doc.InsertParagraph().InsertTableAfterSelf(t);

                    // Сохранение документа
                    doc.Save();

                    // Открытие документа
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(filePath) { UseShellExecute = true });

                    MessageBox.Show($"Накладная сохранена как '{filePath}'");
                }
                else
                {
                    MessageBox.Show("Данные для накладной не найдены.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при создании накладной: " + ex.Message);
            }
        }


    }
}
