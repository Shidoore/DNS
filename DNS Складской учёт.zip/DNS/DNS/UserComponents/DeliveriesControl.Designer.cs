﻿namespace DNS.UserComponents
{
    partial class DeliveriesControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonTexDok = new System.Windows.Forms.Button();
            this.BTDelete = new System.Windows.Forms.Label();
            this.LCount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Lid = new System.Windows.Forms.Label();
            this.LDescProduct = new System.Windows.Forms.Label();
            this.LNameProduct = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Postavshik = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.PrinyalPostavku = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.DataPostavki = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ButtonTexDok
            // 
            this.ButtonTexDok.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.ButtonTexDok.BackColor = System.Drawing.Color.DarkOrange;
            this.ButtonTexDok.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonTexDok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonTexDok.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ButtonTexDok.ForeColor = System.Drawing.Color.White;
            this.ButtonTexDok.Location = new System.Drawing.Point(716, 111);
            this.ButtonTexDok.Name = "ButtonTexDok";
            this.ButtonTexDok.Size = new System.Drawing.Size(185, 41);
            this.ButtonTexDok.TabIndex = 23;
            this.ButtonTexDok.Text = "Тех. документ";
            this.ButtonTexDok.UseVisualStyleBackColor = false;
            this.ButtonTexDok.Click += new System.EventHandler(this.ButtonTexDok_Click);
            // 
            // BTDelete
            // 
            this.BTDelete.AutoSize = true;
            this.BTDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTDelete.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTDelete.Location = new System.Drawing.Point(783, 155);
            this.BTDelete.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTDelete.Name = "BTDelete";
            this.BTDelete.Size = new System.Drawing.Size(55, 17);
            this.BTDelete.TabIndex = 29;
            this.BTDelete.Tag = "0";
            this.BTDelete.Text = "Удалить";
            // 
            // LCount
            // 
            this.LCount.AutoSize = true;
            this.LCount.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.LCount.ForeColor = System.Drawing.Color.DarkOrange;
            this.LCount.Location = new System.Drawing.Point(272, 155);
            this.LCount.Name = "LCount";
            this.LCount.Padding = new System.Windows.Forms.Padding(2);
            this.LCount.Size = new System.Drawing.Size(73, 23);
            this.LCount.TabIndex = 28;
            this.LCount.Text = "%Count%";
            this.LCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(194, 155);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(2);
            this.label2.Size = new System.Drawing.Size(82, 23);
            this.label2.TabIndex = 27;
            this.label2.Text = "В наличии:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lid
            // 
            this.Lid.AutoSize = true;
            this.Lid.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.Lid.Location = new System.Drawing.Point(16, 11);
            this.Lid.Name = "Lid";
            this.Lid.Size = new System.Drawing.Size(46, 20);
            this.Lid.TabIndex = 25;
            this.Lid.Text = "%id%";
            this.Lid.Visible = false;
            // 
            // LDescProduct
            // 
            this.LDescProduct.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.LDescProduct.Location = new System.Drawing.Point(194, 53);
            this.LDescProduct.Name = "LDescProduct";
            this.LDescProduct.Size = new System.Drawing.Size(516, 105);
            this.LDescProduct.TabIndex = 22;
            this.LDescProduct.Text = "%description product%";
            // 
            // LNameProduct
            // 
            this.LNameProduct.AutoSize = true;
            this.LNameProduct.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.LNameProduct.Location = new System.Drawing.Point(192, 11);
            this.LNameProduct.Name = "LNameProduct";
            this.LNameProduct.Size = new System.Drawing.Size(185, 30);
            this.LNameProduct.TabIndex = 21;
            this.LNameProduct.Text = "%name product%";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(20, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(712, 50);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(2);
            this.label1.Size = new System.Drawing.Size(87, 23);
            this.label1.TabIndex = 30;
            this.label1.Text = "Поставщик:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Postavshik
            // 
            this.Postavshik.AutoSize = true;
            this.Postavshik.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Postavshik.ForeColor = System.Drawing.Color.DarkOrange;
            this.Postavshik.Location = new System.Drawing.Point(805, 50);
            this.Postavshik.Name = "Postavshik";
            this.Postavshik.Padding = new System.Windows.Forms.Padding(2);
            this.Postavshik.Size = new System.Drawing.Size(81, 23);
            this.Postavshik.TabIndex = 31;
            this.Postavshik.Text = "%Povshik%";
            this.Postavshik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(712, 18);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(2);
            this.label4.Size = new System.Drawing.Size(64, 23);
            this.label4.TabIndex = 32;
            this.label4.Text = "Принял:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PrinyalPostavku
            // 
            this.PrinyalPostavku.AutoSize = true;
            this.PrinyalPostavku.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PrinyalPostavku.ForeColor = System.Drawing.Color.DarkOrange;
            this.PrinyalPostavku.Location = new System.Drawing.Point(782, 18);
            this.PrinyalPostavku.Name = "PrinyalPostavku";
            this.PrinyalPostavku.Padding = new System.Windows.Forms.Padding(2);
            this.PrinyalPostavku.Size = new System.Drawing.Size(109, 23);
            this.PrinyalPostavku.TabIndex = 33;
            this.PrinyalPostavku.Text = "%PrinyalTovar%";
            this.PrinyalPostavku.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label6.Location = new System.Drawing.Point(361, 155);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(2);
            this.label6.Size = new System.Drawing.Size(107, 23);
            this.label6.TabIndex = 34;
            this.label6.Text = "Дата поставки:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DataPostavki
            // 
            this.DataPostavki.AutoSize = true;
            this.DataPostavki.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.DataPostavki.ForeColor = System.Drawing.Color.DarkOrange;
            this.DataPostavki.Location = new System.Drawing.Point(474, 154);
            this.DataPostavki.Name = "DataPostavki";
            this.DataPostavki.Padding = new System.Windows.Forms.Padding(2);
            this.DataPostavki.Size = new System.Drawing.Size(114, 23);
            this.DataPostavki.TabIndex = 35;
            this.DataPostavki.Text = "%DataPostavki%";
            this.DataPostavki.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DeliveriesControl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.DataPostavki);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PrinyalPostavku);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Postavshik);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonTexDok);
            this.Controls.Add(this.BTDelete);
            this.Controls.Add(this.LCount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lid);
            this.Controls.Add(this.LDescProduct);
            this.Controls.Add(this.LNameProduct);
            this.Controls.Add(this.pictureBox1);
            this.Name = "DeliveriesControl";
            this.Size = new System.Drawing.Size(916, 189);
            this.Load += new System.EventHandler(this.DeliveriesControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonTexDok;
        private System.Windows.Forms.Label BTDelete;
        private System.Windows.Forms.Label LCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Lid;
        private System.Windows.Forms.Label LDescProduct;
        private System.Windows.Forms.Label LNameProduct;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Postavshik;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label PrinyalPostavku;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label DataPostavki;
    }
}
