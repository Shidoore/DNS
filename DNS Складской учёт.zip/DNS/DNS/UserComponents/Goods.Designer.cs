﻿namespace DNS.UserComponents
{
    partial class Goods
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.LMoneyDiscount = new System.Windows.Forms.Label();
            this.Lid = new System.Windows.Forms.Label();
            this.LMoney = new System.Windows.Forms.Label();
            this.LDescProduct = new System.Windows.Forms.Label();
            this.LNameProduct = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LCount = new System.Windows.Forms.Label();
            this.BTDelete = new System.Windows.Forms.Label();
            this.ButtonTexDok = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LMoneyDiscount
            // 
            this.LMoneyDiscount.AutoSize = true;
            this.LMoneyDiscount.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Strikeout))));
            this.LMoneyDiscount.Location = new System.Drawing.Point(719, 59);
            this.LMoneyDiscount.Name = "LMoneyDiscount";
            this.LMoneyDiscount.Padding = new System.Windows.Forms.Padding(2);
            this.LMoneyDiscount.Size = new System.Drawing.Size(93, 23);
            this.LMoneyDiscount.TabIndex = 15;
            this.LMoneyDiscount.Text = "%discount%";
            this.LMoneyDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lid
            // 
            this.Lid.AutoSize = true;
            this.Lid.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.Lid.Location = new System.Drawing.Point(18, 10);
            this.Lid.Name = "Lid";
            this.Lid.Size = new System.Drawing.Size(46, 20);
            this.Lid.TabIndex = 14;
            this.Lid.Text = "%id%";
            this.Lid.Visible = false;
            // 
            // LMoney
            // 
            this.LMoney.AutoSize = true;
            this.LMoney.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LMoney.Location = new System.Drawing.Point(718, 78);
            this.LMoney.Name = "LMoney";
            this.LMoney.Padding = new System.Windows.Forms.Padding(2);
            this.LMoney.Size = new System.Drawing.Size(109, 29);
            this.LMoney.TabIndex = 13;
            this.LMoney.Text = "%money%";
            this.LMoney.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LDescProduct
            // 
            this.LDescProduct.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.LDescProduct.Location = new System.Drawing.Point(196, 52);
            this.LDescProduct.Name = "LDescProduct";
            this.LDescProduct.Size = new System.Drawing.Size(516, 105);
            this.LDescProduct.TabIndex = 10;
            this.LDescProduct.Text = "%description product%";
            // 
            // LNameProduct
            // 
            this.LNameProduct.AutoSize = true;
            this.LNameProduct.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.LNameProduct.Location = new System.Drawing.Point(194, 10);
            this.LNameProduct.Name = "LNameProduct";
            this.LNameProduct.Size = new System.Drawing.Size(185, 30);
            this.LNameProduct.TabIndex = 9;
            this.LNameProduct.Text = "%name product%";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(22, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(196, 154);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(2);
            this.label2.Size = new System.Drawing.Size(82, 23);
            this.label2.TabIndex = 16;
            this.label2.Text = "В наличии:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LCount
            // 
            this.LCount.AutoSize = true;
            this.LCount.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.LCount.ForeColor = System.Drawing.Color.DarkOrange;
            this.LCount.Location = new System.Drawing.Point(274, 154);
            this.LCount.Name = "LCount";
            this.LCount.Padding = new System.Windows.Forms.Padding(2);
            this.LCount.Size = new System.Drawing.Size(73, 23);
            this.LCount.TabIndex = 17;
            this.LCount.Text = "%Count%";
            this.LCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BTDelete
            // 
            this.BTDelete.AutoSize = true;
            this.BTDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTDelete.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTDelete.Location = new System.Drawing.Point(785, 154);
            this.BTDelete.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTDelete.Name = "BTDelete";
            this.BTDelete.Size = new System.Drawing.Size(55, 17);
            this.BTDelete.TabIndex = 19;
            this.BTDelete.Tag = "0";
            this.BTDelete.Text = "Удалить";
            this.BTDelete.Click += new System.EventHandler(this.BTDelete_Click);
            // 
            // ButtonTexDok
            // 
            this.ButtonTexDok.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.ButtonTexDok.BackColor = System.Drawing.Color.DarkOrange;
            this.ButtonTexDok.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonTexDok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonTexDok.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ButtonTexDok.ForeColor = System.Drawing.Color.White;
            this.ButtonTexDok.Location = new System.Drawing.Point(718, 110);
            this.ButtonTexDok.Name = "ButtonTexDok";
            this.ButtonTexDok.Size = new System.Drawing.Size(185, 41);
            this.ButtonTexDok.TabIndex = 11;
            this.ButtonTexDok.Text = "Тех. документ";
            this.ButtonTexDok.UseVisualStyleBackColor = false;
            // 
            // Goods
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ButtonTexDok);
            this.Controls.Add(this.BTDelete);
            this.Controls.Add(this.LCount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LMoneyDiscount);
            this.Controls.Add(this.Lid);
            this.Controls.Add(this.LMoney);
            this.Controls.Add(this.LDescProduct);
            this.Controls.Add(this.LNameProduct);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(10);
            this.Name = "Goods";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(916, 189);
            this.Load += new System.EventHandler(this.Goods_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LMoneyDiscount;
        private System.Windows.Forms.Label Lid;
        private System.Windows.Forms.Label LMoney;
        private System.Windows.Forms.Label LDescProduct;
        private System.Windows.Forms.Label LNameProduct;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LCount;
        private System.Windows.Forms.Label BTDelete;
        private System.Windows.Forms.Button ButtonTexDok;
    }
}
