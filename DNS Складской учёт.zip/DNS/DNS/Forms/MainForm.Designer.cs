﻿namespace DNS
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTPostavkiTovara = new System.Windows.Forms.Label();
            this.BTAddNewGoods = new System.Windows.Forms.Label();
            this.BTCreateNewAccount = new System.Windows.Forms.Label();
            this.TBSearch = new System.Windows.Forms.TextBox();
            this.BTRProfile = new DNS.RoundedButton();
            this.PBSearch = new System.Windows.Forms.PictureBox();
            this.PBLogopic = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBLogopic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.BTPostavkiTovara);
            this.panel1.Controls.Add(this.BTAddNewGoods);
            this.panel1.Controls.Add(this.BTCreateNewAccount);
            this.panel1.Controls.Add(this.TBSearch);
            this.panel1.Controls.Add(this.BTRProfile);
            this.panel1.Controls.Add(this.PBSearch);
            this.panel1.Controls.Add(this.PBLogopic);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(964, 91);
            this.panel1.TabIndex = 1;
            // 
            // BTPostavkiTovara
            // 
            this.BTPostavkiTovara.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BTPostavkiTovara.AutoSize = true;
            this.BTPostavkiTovara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTPostavkiTovara.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Underline);
            this.BTPostavkiTovara.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTPostavkiTovara.Location = new System.Drawing.Point(484, 68);
            this.BTPostavkiTovara.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTPostavkiTovara.Name = "BTPostavkiTovara";
            this.BTPostavkiTovara.Size = new System.Drawing.Size(122, 19);
            this.BTPostavkiTovara.TabIndex = 19;
            this.BTPostavkiTovara.Tag = "0";
            this.BTPostavkiTovara.Text = "Поставки товара";
            this.BTPostavkiTovara.Click += new System.EventHandler(this.BTPostavkiTovara_Click);
            // 
            // BTAddNewGoods
            // 
            this.BTAddNewGoods.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BTAddNewGoods.AutoSize = true;
            this.BTAddNewGoods.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTAddNewGoods.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Underline);
            this.BTAddNewGoods.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTAddNewGoods.Location = new System.Drawing.Point(610, 68);
            this.BTAddNewGoods.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTAddNewGoods.Name = "BTAddNewGoods";
            this.BTAddNewGoods.Size = new System.Drawing.Size(166, 19);
            this.BTAddNewGoods.TabIndex = 18;
            this.BTAddNewGoods.Tag = "0";
            this.BTAddNewGoods.Text = "Добавить новый товар";
            this.BTAddNewGoods.Click += new System.EventHandler(this.BTAddNewGoods_Click);
            // 
            // BTCreateNewAccount
            // 
            this.BTCreateNewAccount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BTCreateNewAccount.AutoSize = true;
            this.BTCreateNewAccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTCreateNewAccount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Underline);
            this.BTCreateNewAccount.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTCreateNewAccount.Location = new System.Drawing.Point(780, 68);
            this.BTCreateNewAccount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTCreateNewAccount.Name = "BTCreateNewAccount";
            this.BTCreateNewAccount.Size = new System.Drawing.Size(169, 19);
            this.BTCreateNewAccount.TabIndex = 17;
            this.BTCreateNewAccount.Tag = "0";
            this.BTCreateNewAccount.Text = "Создать новый аккаунт";
            this.BTCreateNewAccount.Click += new System.EventHandler(this.BTCreateNewAccount_Click);
            // 
            // TBSearch
            // 
            this.TBSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.TBSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBSearch.ForeColor = System.Drawing.Color.Gray;
            this.TBSearch.Location = new System.Drawing.Point(225, 18);
            this.TBSearch.Name = "TBSearch";
            this.TBSearch.Size = new System.Drawing.Size(407, 31);
            this.TBSearch.TabIndex = 0;
            this.TBSearch.Text = "Поиск по товарам";
            this.TBSearch.TextChanged += new System.EventHandler(this.TBSearch_TextChanged);
            this.TBSearch.Enter += new System.EventHandler(this.TBSearch_Enter);
            this.TBSearch.Leave += new System.EventHandler(this.TBSearch_Leave);
            // 
            // BTRProfile
            // 
            this.BTRProfile.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BTRProfile.BackColor = System.Drawing.Color.White;
            this.BTRProfile.BackgroundColor = System.Drawing.Color.White;
            this.BTRProfile.BackgroundImage = global::DNS.Properties.Resources.NoAvatar;
            this.BTRProfile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BTRProfile.BorderColor = System.Drawing.Color.Black;
            this.BTRProfile.BorderRadius = 30;
            this.BTRProfile.BorderSize = 2;
            this.BTRProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTRProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTRProfile.ForeColor = System.Drawing.Color.White;
            this.BTRProfile.Location = new System.Drawing.Point(891, 3);
            this.BTRProfile.Name = "BTRProfile";
            this.BTRProfile.Size = new System.Drawing.Size(60, 60);
            this.BTRProfile.TabIndex = 2;
            this.BTRProfile.TextColor = System.Drawing.Color.White;
            this.BTRProfile.UseVisualStyleBackColor = false;
            this.BTRProfile.Click += new System.EventHandler(this.BTRProfile_Click);
            // 
            // PBSearch
            // 
            this.PBSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PBSearch.Image = global::DNS.Properties.Resources.Search;
            this.PBSearch.Location = new System.Drawing.Point(632, 17);
            this.PBSearch.Name = "PBSearch";
            this.PBSearch.Size = new System.Drawing.Size(32, 33);
            this.PBSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBSearch.TabIndex = 1;
            this.PBSearch.TabStop = false;
            // 
            // PBLogopic
            // 
            this.PBLogopic.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PBLogopic.Image = global::DNS.Properties.Resources.DNSLogo;
            this.PBLogopic.Location = new System.Drawing.Point(12, 3);
            this.PBLogopic.Name = "PBLogopic";
            this.PBLogopic.Size = new System.Drawing.Size(207, 60);
            this.PBLogopic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBLogopic.TabIndex = 0;
            this.PBLogopic.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Gainsboro;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 90);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(961, 442);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(961, 532);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial Narrow", 14.25F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimumSize = new System.Drawing.Size(977, 571);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Складской учёт";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBLogopic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PBLogopic;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox PBSearch;
        private RoundedButton BTRProfile;
        private System.Windows.Forms.TextBox TBSearch;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label BTCreateNewAccount;
        private System.Windows.Forms.Label BTAddNewGoods;
        private System.Windows.Forms.Label BTPostavkiTovara;
    }
}