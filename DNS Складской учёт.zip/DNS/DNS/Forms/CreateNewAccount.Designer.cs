﻿namespace DNS.Forms
{
    partial class CreateNewAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateNewAccount));
            this.BTBack = new System.Windows.Forms.Label();
            this.BTSave = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TBEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TBLastName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TBName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TBPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TBLogin = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TBSurname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TBNumber = new System.Windows.Forms.MaskedTextBox();
            this.PBImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).BeginInit();
            this.SuspendLayout();
            // 
            // BTBack
            // 
            this.BTBack.AutoSize = true;
            this.BTBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTBack.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTBack.Location = new System.Drawing.Point(26, 380);
            this.BTBack.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTBack.Name = "BTBack";
            this.BTBack.Size = new System.Drawing.Size(59, 23);
            this.BTBack.TabIndex = 7;
            this.BTBack.Tag = "0";
            this.BTBack.Text = "Назад";
            this.BTBack.Click += new System.EventHandler(this.BTBack_Click);
            // 
            // BTSave
            // 
            this.BTSave.AutoSize = true;
            this.BTSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTSave.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTSave.Location = new System.Drawing.Point(394, 380);
            this.BTSave.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTSave.Name = "BTSave";
            this.BTSave.Size = new System.Drawing.Size(74, 23);
            this.BTSave.TabIndex = 8;
            this.BTSave.Tag = "2";
            this.BTSave.Text = "Создать";
            this.BTSave.Click += new System.EventHandler(this.BTSave_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14F);
            this.label6.Location = new System.Drawing.Point(113, 326);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 23);
            this.label6.TabIndex = 27;
            this.label6.Text = "Почта:";
            // 
            // TBEmail
            // 
            this.TBEmail.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBEmail.Location = new System.Drawing.Point(180, 323);
            this.TBEmail.MaxLength = 100;
            this.TBEmail.Name = "TBEmail";
            this.TBEmail.Size = new System.Drawing.Size(288, 31);
            this.TBEmail.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14F);
            this.label5.Location = new System.Drawing.Point(26, 279);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 23);
            this.label5.TabIndex = 25;
            this.label5.Text = "Номер телефона:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14F);
            this.label4.Location = new System.Drawing.Point(165, 173);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 23);
            this.label4.TabIndex = 23;
            this.label4.Text = "Отчество:";
            // 
            // TBLastName
            // 
            this.TBLastName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBLastName.Location = new System.Drawing.Point(254, 173);
            this.TBLastName.MaxLength = 100;
            this.TBLastName.Name = "TBLastName";
            this.TBLastName.Size = new System.Drawing.Size(214, 31);
            this.TBLastName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14F);
            this.label3.Location = new System.Drawing.Point(203, 125);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 23);
            this.label3.TabIndex = 21;
            this.label3.Text = "Имя:";
            // 
            // TBName
            // 
            this.TBName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBName.Location = new System.Drawing.Point(254, 122);
            this.TBName.MaxLength = 100;
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(214, 31);
            this.TBName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14F);
            this.label2.Location = new System.Drawing.Point(244, 227);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 23);
            this.label2.TabIndex = 19;
            this.label2.Text = "Пароль:*";
            // 
            // TBPassword
            // 
            this.TBPassword.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBPassword.Location = new System.Drawing.Point(328, 224);
            this.TBPassword.MaxLength = 40;
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.Size = new System.Drawing.Size(140, 31);
            this.TBPassword.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(25, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 29);
            this.label1.TabIndex = 17;
            this.label1.Text = "Создание нового аккаунта";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14F);
            this.label7.Location = new System.Drawing.Point(26, 227);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 23);
            this.label7.TabIndex = 33;
            this.label7.Text = "Логин:*";
            // 
            // TBLogin
            // 
            this.TBLogin.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBLogin.Location = new System.Drawing.Point(99, 224);
            this.TBLogin.MaxLength = 40;
            this.TBLogin.Name = "TBLogin";
            this.TBLogin.Size = new System.Drawing.Size(140, 31);
            this.TBLogin.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 14F);
            this.label8.Location = new System.Drawing.Point(160, 75);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 23);
            this.label8.TabIndex = 35;
            this.label8.Text = "Фамилия:";
            // 
            // TBSurname
            // 
            this.TBSurname.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBSurname.Location = new System.Drawing.Point(254, 75);
            this.TBSurname.MaxLength = 100;
            this.TBSurname.Name = "TBSurname";
            this.TBSurname.Size = new System.Drawing.Size(214, 31);
            this.TBSurname.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 10F);
            this.label9.Location = new System.Drawing.Point(331, 357);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 17);
            this.label9.TabIndex = 36;
            this.label9.Text = "* - обязательное поле";
            // 
            // TBNumber
            // 
            this.TBNumber.Location = new System.Drawing.Point(180, 276);
            this.TBNumber.Mask = "+7-000-000-00-00";
            this.TBNumber.Name = "TBNumber";
            this.TBNumber.Size = new System.Drawing.Size(288, 31);
            this.TBNumber.TabIndex = 37;
            // 
            // PBImg
            // 
            this.PBImg.BackColor = System.Drawing.Color.Gainsboro;
            this.PBImg.BackgroundImage = global::DNS.Properties.Resources.NoPhoto;
            this.PBImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PBImg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBImg.Image = global::DNS.Properties.Resources.PhotoChange_;
            this.PBImg.Location = new System.Drawing.Point(30, 75);
            this.PBImg.Name = "PBImg";
            this.PBImg.Size = new System.Drawing.Size(130, 130);
            this.PBImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBImg.TabIndex = 41;
            this.PBImg.TabStop = false;
            this.PBImg.Click += new System.EventHandler(this.PBImg_Click);
            // 
            // CreateNewAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(495, 423);
            this.Controls.Add(this.PBImg);
            this.Controls.Add(this.TBNumber);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TBSurname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TBLogin);
            this.Controls.Add(this.BTBack);
            this.Controls.Add(this.BTSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TBEmail);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TBLastName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CreateNewAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateNewAccount";
            this.Load += new System.EventHandler(this.CreateNewAccount_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label BTBack;
        private System.Windows.Forms.Label BTSave;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TBEmail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TBLastName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBLogin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TBSurname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox TBNumber;
        private System.Windows.Forms.PictureBox PBImg;
    }
}