﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNS.Forms
{
    public partial class CreateNewAccount : Form
    {
        bool IsHaveImg = false;
        byte[] image_bytes;
        public CreateNewAccount()
        {
            InitializeComponent();
        }

        private void PBImg_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Файлы картинок|*.jpg;*.jpeg;*.png;";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    IsHaveImg = true;
                    PBImg.BackgroundImage = Image.FromFile(ofd.FileName);
                    image_bytes = File.ReadAllBytes(ofd.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BTSave_Click(object sender, EventArgs e)
        {
            if (TBLogin.Text != "" & TBPassword.Text != "")
            {
                DataTable _table = DataBase.fromDB($"select [login] from [users] where [login] ='{TBLogin.Text}'");

                if (_table.Rows.Count == 0)
                {
                    if (TBSurname.Text == "") TBSurname.Text = "Не указано";
                    if (TBName.Text == "") TBName.Text = "Не указано";
                    if (TBLastName.Text == "") TBLastName.Text = "Не указано";
                    if (TBEmail.Text == "") TBEmail.Text = "Не указано";
                    string number = TBNumber.Text;
                    TBNumber.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                    if (String.IsNullOrEmpty(TBNumber.Text) || String.IsNullOrWhiteSpace(TBNumber.Text))
                        number = "Не указано";

                        DataBase.toDB($"insert into [users]([surname],[name],[lastname],[login],[password],[number],[email])" +
                              $"values('{TBSurname.Text}', '{TBName.Text}', '{TBLastName.Text}', '{TBLogin.Text}', '{TBPassword.Text}', '{number}', '{TBEmail.Text}')");

                    if (IsHaveImg == true)
                    {
                        DataTable userId = DataBase.fromDB($"select [id] from [users] where [login] = '{TBLogin.Text}'");
                        DataBase.ImageToDB($"Update [users] set [photo] = @ImageData where id = '{userId.Rows[0]["id"]}'", image_bytes);
                    }
                    MessageBox.Show("Добавлен новый аккаунт, приятного", "Создан новый аккаунт");
                    this.Close();
                }
                else
                    MessageBox.Show("Логин уже занят, выберите другой", "Ошибка создания", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
                MessageBox.Show("Заполните обязательные поля","Ошибка создания", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }

        private void BTBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CreateNewAccount_Load(object sender, EventArgs e)
        {

        }
    }
}
