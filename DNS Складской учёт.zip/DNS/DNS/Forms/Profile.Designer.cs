﻿namespace DNS
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            this.label1 = new System.Windows.Forms.Label();
            this.TBSurname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TBName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TBLastName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TBEmail = new System.Windows.Forms.TextBox();
            this.BTSave = new System.Windows.Forms.Label();
            this.BTLogout = new System.Windows.Forms.Label();
            this.BTBack = new System.Windows.Forms.Label();
            this.TBNumber = new System.Windows.Forms.MaskedTextBox();
            this.PBImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(25, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Профиль";
            // 
            // TBSurname
            // 
            this.TBSurname.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBSurname.Location = new System.Drawing.Point(254, 76);
            this.TBSurname.MaxLength = 100;
            this.TBSurname.Name = "TBSurname";
            this.TBSurname.Size = new System.Drawing.Size(214, 31);
            this.TBSurname.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14F);
            this.label2.Location = new System.Drawing.Point(163, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Фамилия:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14F);
            this.label3.Location = new System.Drawing.Point(203, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "Имя:";
            // 
            // TBName
            // 
            this.TBName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBName.Location = new System.Drawing.Point(254, 127);
            this.TBName.MaxLength = 100;
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(214, 31);
            this.TBName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14F);
            this.label4.Location = new System.Drawing.Point(165, 175);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "Отчество:";
            // 
            // TBLastName
            // 
            this.TBLastName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBLastName.Location = new System.Drawing.Point(254, 175);
            this.TBLastName.MaxLength = 100;
            this.TBLastName.Name = "TBLastName";
            this.TBLastName.Size = new System.Drawing.Size(214, 31);
            this.TBLastName.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14F);
            this.label5.Location = new System.Drawing.Point(26, 226);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 23);
            this.label5.TabIndex = 9;
            this.label5.Text = "Номер телефона:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14F);
            this.label6.Location = new System.Drawing.Point(113, 273);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 23);
            this.label6.TabIndex = 11;
            this.label6.Text = "Почта:";
            // 
            // TBEmail
            // 
            this.TBEmail.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBEmail.Location = new System.Drawing.Point(180, 270);
            this.TBEmail.MaxLength = 100;
            this.TBEmail.Name = "TBEmail";
            this.TBEmail.Size = new System.Drawing.Size(288, 31);
            this.TBEmail.TabIndex = 10;
            // 
            // BTSave
            // 
            this.BTSave.AutoSize = true;
            this.BTSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTSave.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTSave.Location = new System.Drawing.Point(375, 322);
            this.BTSave.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTSave.Name = "BTSave";
            this.BTSave.Size = new System.Drawing.Size(93, 23);
            this.BTSave.TabIndex = 12;
            this.BTSave.Tag = "2";
            this.BTSave.Text = "Сохранить";
            this.BTSave.Click += new System.EventHandler(this.BTSave_Click);
            this.BTSave.MouseEnter += new System.EventHandler(this.Buttons_MouseEnter);
            this.BTSave.MouseLeave += new System.EventHandler(this.Buttons_MouseLeave);
            // 
            // BTLogout
            // 
            this.BTLogout.AutoSize = true;
            this.BTLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTLogout.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTLogout.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTLogout.Location = new System.Drawing.Point(203, 322);
            this.BTLogout.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTLogout.Name = "BTLogout";
            this.BTLogout.Size = new System.Drawing.Size(157, 23);
            this.BTLogout.TabIndex = 13;
            this.BTLogout.Tag = "1";
            this.BTLogout.Text = "Выйти из аккаунта";
            this.BTLogout.Click += new System.EventHandler(this.BTLogout_Click);
            this.BTLogout.MouseEnter += new System.EventHandler(this.Buttons_MouseEnter);
            this.BTLogout.MouseLeave += new System.EventHandler(this.Buttons_MouseLeave);
            // 
            // BTBack
            // 
            this.BTBack.AutoSize = true;
            this.BTBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTBack.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTBack.Location = new System.Drawing.Point(26, 322);
            this.BTBack.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTBack.Name = "BTBack";
            this.BTBack.Size = new System.Drawing.Size(59, 23);
            this.BTBack.TabIndex = 14;
            this.BTBack.Tag = "0";
            this.BTBack.Text = "Назад";
            this.BTBack.Click += new System.EventHandler(this.BTBack_Click);
            this.BTBack.MouseEnter += new System.EventHandler(this.Buttons_MouseEnter);
            this.BTBack.MouseLeave += new System.EventHandler(this.Buttons_MouseLeave);
            // 
            // TBNumber
            // 
            this.TBNumber.Location = new System.Drawing.Point(180, 223);
            this.TBNumber.Mask = "+7-000-000-00-00";
            this.TBNumber.Name = "TBNumber";
            this.TBNumber.Size = new System.Drawing.Size(288, 31);
            this.TBNumber.TabIndex = 17;
            // 
            // PBImg
            // 
            this.PBImg.BackColor = System.Drawing.Color.Gainsboro;
            this.PBImg.BackgroundImage = global::DNS.Properties.Resources.NoAvatar;
            this.PBImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PBImg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBImg.Image = global::DNS.Properties.Resources.PhotoChange_;
            this.PBImg.Location = new System.Drawing.Point(30, 76);
            this.PBImg.Name = "PBImg";
            this.PBImg.Size = new System.Drawing.Size(130, 130);
            this.PBImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBImg.TabIndex = 42;
            this.PBImg.TabStop = false;
            this.PBImg.Click += new System.EventHandler(this.PBImg_Click);
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(495, 361);
            this.Controls.Add(this.PBImg);
            this.Controls.Add(this.TBNumber);
            this.Controls.Add(this.BTBack);
            this.Controls.Add(this.BTLogout);
            this.Controls.Add(this.BTSave);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TBEmail);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TBLastName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBSurname);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Profile";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBSurname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TBLastName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TBEmail;
        private System.Windows.Forms.Label BTSave;
        private System.Windows.Forms.Label BTLogout;
        private System.Windows.Forms.Label BTBack;
        private System.Windows.Forms.MaskedTextBox TBNumber;
        private System.Windows.Forms.PictureBox PBImg;
    }
}