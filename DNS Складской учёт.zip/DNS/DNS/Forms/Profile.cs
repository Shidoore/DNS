﻿using DNS.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNS
{
    public partial class Profile : Form
    {
        public string userId = "1";
        bool IsHaveImg = false;
        byte[] image_bytes;
        public Profile()
        {
            InitializeComponent();
        }

        #region visual
        private void Buttons_MouseEnter(object sender, EventArgs e)
        {
            var _label = (Label)sender;
            _label.ForeColor = Color.SteelBlue;
        }

        private void Buttons_MouseLeave(object sender, EventArgs e)
        {
            var _label = (Label)sender;
            _label.ForeColor = Color.DarkOrange;
        }
        #endregion

        private void Profile_Load(object sender, EventArgs e)
        {

            DataTable _table = DataBase.fromDB($"select [surname],[name],[lastname],[number],[email],[photo] from [users] " +
                $"where [id] ='{userId}'");

            TBSurname.Text = _table.Rows[0][0].ToString();
            TBName.Text = _table.Rows[0][1].ToString();
            TBLastName.Text = _table.Rows[0][2].ToString();
            TBNumber.Text = _table.Rows[0][3].ToString();
            TBEmail.Text = _table.Rows[0][4].ToString();
            if (_table.Rows[0][5].ToString() != "")
                PBImg.BackgroundImage = DataBase.ImageFromByte((Byte[])_table.Rows[0][5]);
            else
                PBImg.BackgroundImage = Properties.Resources.NoAvatar;
        }

        private void PBImg_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Файлы картинок|*.jpg;*.jpeg;*.png;";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    IsHaveImg = true;
                    PBImg.BackgroundImage = Image.FromFile(ofd.FileName);
                    image_bytes = File.ReadAllBytes(ofd.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BTSave_Click(object sender, EventArgs e)
        {
            DialogResult dr = 
                MessageBox.Show("Вы уверенны, что хотите изменить свои данные?","Подтверждение", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.OK)
            {
                if (TBSurname.Text == "") TBSurname.Text = "Не указано";
                if (TBName.Text == "") TBName.Text = "Не указано";
                if (TBLastName.Text == "") TBLastName.Text = "Не указано";
                if (TBEmail.Text == "") TBEmail.Text = "Не указано";
                string number = TBNumber.Text;
                TBNumber.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                if (String.IsNullOrEmpty(TBNumber.Text) || String.IsNullOrWhiteSpace(TBNumber.Text))
                    number = "Не указано";

                DataBase.toDB($"Update [users] set [surname]='{TBSurname.Text}',[name]='{TBName.Text}',[lastname]='{TBLastName.Text}',[number]='{number}',[email]='{TBEmail.Text}' " +
                          $"where [id]='{userId}'");

                if (IsHaveImg == true)
                    DataBase.ImageToDB($"Update [users] set [photo] = @ImageData where id = '{userId}'", image_bytes);

                DialogResult = DialogResult.Yes;
            }
        }

        private void BTBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTLogout_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
