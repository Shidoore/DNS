﻿using DNS.Forms;
using DNS.UserComponents;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNS
{
    public partial class MainForm : Form
    {
        public string userRole = "Пользователь";
        public string userId = "1";
        public MainForm()
        {
            InitializeComponent();
            TBSearch.TextChanged += TBSearch_TextChanged;
        }

        #region visual
        private void TBSearch_Enter(object sender, EventArgs e)
        {
            if (TBSearch.Text == "Поиск по товарам")
            {
                TBSearch.Text = null;
                TBSearch.ForeColor = Color.Black;
                PBSearch.Image = Properties.Resources.SearchActive;
            }
        }

        private void TBSearch_Leave(object sender, EventArgs e)
        {
            if (TBSearch.Text == "")
            {
                TBSearch.Text = "Поиск по товарам";
                TBSearch.ForeColor = Color.Gray;
                PBSearch.Image = Properties.Resources.Search;
            }
        }
        #endregion

        private void MainForm_Load(object sender, EventArgs e)
        {
            if (userRole == "Администратор")
            {
                BTCreateNewAccount.Visible = true;
                BTAddNewGoods.Visible = true;
            }
            else
            {
                BTCreateNewAccount.Visible = false;
                BTAddNewGoods.Visible= false;
            }

            LoadProfilePhoto();
            ShowProductControl();
        }

        private void LoadProfilePhoto()
        {
            DataTable _table = DataBase.fromDB($"select [photo] from [users] where [id] ='{userId}'");
            if (_table.Rows[0]["photo"].ToString() != "")
                BTRProfile.BackgroundImage = DataBase.ImageFromByte((Byte[])_table.Rows[0][0]);
            else
                BTRProfile.BackgroundImage = Properties.Resources.NoAvatar;
        }

        private void ShowProductControl()
        {
            DataTable table = DataBase.fromDB($"select * from [products]");
            if (table != null)
            {
                flowLayoutPanel1.Controls.Clear();
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    Goods item = new Goods();
                    item.userRole = this.userRole;

                    item.BorderColor = Color.White;
                    item.BorderSize = 2;
                    item.BorderRadius = 15;

                    item.product_id = (int)table.Rows[i]["id"];
                    flowLayoutPanel1.Controls.Add(item);
                }
            }
        }

        private void ShowDeliveriesControl()
        {
            // Загрузка данных поставок
            DataTable table = DataBase.fromDB("SELECT * FROM [deliveries]");
            if (table != null)
            {
                flowLayoutPanel1.Controls.Clear();
                foreach (DataRow row in table.Rows)
                {
                    DeliveriesControl control = new DeliveriesControl();
                    control.userRole = this.userRole;

                    control.BorderColor = Color.White;
                    control.BorderSize = 2;
                    control.BorderRadius = 15;

                    control.deliveryId = (int)row["id"];
                    flowLayoutPanel1.Controls.Add(control);
                }
            }
        }

        private void TBSearch_TextChanged(object sender, EventArgs e)
        {
            // Проверяем, пустой ли поисковый запрос
            if (string.IsNullOrWhiteSpace(TBSearch.Text) || TBSearch.Text == "Поиск по товарам")
            {
                ShowProductControl(); // Загружаем все товары, если поисковый запрос пустой
                return;
            }

            // Выполняем запрос к базе данных
            DataTable table = DataBase.fromDB($"SELECT * FROM [products] WHERE [name] LIKE '%{TBSearch.Text}%'");

            // Обновляем отображение результатов в flowLayoutPanel1
            if (table != null)
            {
                flowLayoutPanel1.Controls.Clear();
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    Goods item = new Goods();
                    item.userRole = this.userRole;

                    item.BorderColor = Color.White;
                    item.BorderSize = 2;
                    item.BorderRadius = 15;
                    item.product_id = (int)table.Rows[i]["id"];
                    flowLayoutPanel1.Controls.Add(item);
                }
            }
        }

        private void BTRProfile_Click(object sender, EventArgs e)
        {
            Profile _profile = new Profile();
            _profile.userId = this.userId;
            DialogResult dr = _profile.ShowDialog();
            if (dr == DialogResult.Yes)
                LoadProfilePhoto();

        }

        private void BTCreateNewAccount_Click(object sender, EventArgs e)
        {
            CreateNewAccount createNewAccount = new CreateNewAccount();
            createNewAccount.ShowDialog();
        }

        private void BTAddNewGoods_Click(object sender, EventArgs e)
        {
            AddNewGoods addNewGoods = new AddNewGoods();
            DialogResult dr = addNewGoods.ShowDialog();
            if (dr == DialogResult.Yes)
                ShowProductControl();
        }

        private void BTPostavkiTovara_Click(object sender, EventArgs e)
        {
            ShowDeliveriesControl();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

    }
}
    