﻿namespace DNS
{
    partial class Auth
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Auth));
            this.label1 = new System.Windows.Forms.Label();
            this.TBLogin = new System.Windows.Forms.TextBox();
            this.TBPassword = new System.Windows.Forms.TextBox();
            this.BTLogin = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(80, 109);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Авторизация";
            // 
            // TBLogin
            // 
            this.TBLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TBLogin.ForeColor = System.Drawing.Color.Silver;
            this.TBLogin.Location = new System.Drawing.Point(42, 172);
            this.TBLogin.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TBLogin.Name = "TBLogin";
            this.TBLogin.Size = new System.Drawing.Size(240, 29);
            this.TBLogin.TabIndex = 2;
            this.TBLogin.Tag = "Логин";
            this.TBLogin.Text = "Логин";
            this.TBLogin.TextChanged += new System.EventHandler(this.TBLogin_TextChanged);
            this.TBLogin.Enter += new System.EventHandler(this.TextBox_Enter);
            this.TBLogin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            this.TBLogin.Leave += new System.EventHandler(this.TextBox_Leave);
            // 
            // TBPassword
            // 
            this.TBPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TBPassword.ForeColor = System.Drawing.Color.Silver;
            this.TBPassword.Location = new System.Drawing.Point(42, 223);
            this.TBPassword.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TBPassword.Name = "TBPassword";
            this.TBPassword.Size = new System.Drawing.Size(240, 29);
            this.TBPassword.TabIndex = 4;
            this.TBPassword.Tag = "Пароль";
            this.TBPassword.Text = "Пароль";
            this.TBPassword.Enter += new System.EventHandler(this.TextBox_Enter);
            this.TBPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            this.TBPassword.Leave += new System.EventHandler(this.TextBox_Leave);
            // 
            // BTLogin
            // 
            this.BTLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BTLogin.BackColor = System.Drawing.Color.DarkOrange;
            this.BTLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTLogin.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTLogin.ForeColor = System.Drawing.Color.White;
            this.BTLogin.Location = new System.Drawing.Point(42, 271);
            this.BTLogin.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTLogin.Name = "BTLogin";
            this.BTLogin.Size = new System.Drawing.Size(240, 33);
            this.BTLogin.TabIndex = 6;
            this.BTLogin.Text = "Войти";
            this.BTLogin.UseVisualStyleBackColor = false;
            this.BTLogin.Click += new System.EventHandler(this.BTLogin_Click);
            this.BTLogin.Enter += new System.EventHandler(this.Button_Enter);
            this.BTLogin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBox_KeyDown);
            this.BTLogin.Leave += new System.EventHandler(this.Button_Leave);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(149, 386);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "© 2024 Юрик Петросян.";
            // 
            // Auth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(324, 411);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BTLogin);
            this.Controls.Add(this.TBPassword);
            this.Controls.Add(this.TBLogin);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MinimumSize = new System.Drawing.Size(340, 450);
            this.Name = "Auth";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBLogin;
        private System.Windows.Forms.TextBox TBPassword;
        private System.Windows.Forms.Button BTLogin;
        private System.Windows.Forms.Label label2;
    }
}

