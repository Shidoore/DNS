﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Xml.Linq;
using System.IO;

namespace DNS.Forms
{
    public partial class AddNewGoods : Form
    {
        bool IsCategoryNew = true;
        bool IsHaveDiscount = false;
        bool IsHaveImg = false;
        byte[] image_bytes;

        public AddNewGoods()
        {
            InitializeComponent();
        }

        private void AddNewGoods_Load(object sender, EventArgs e)
        {
            DataTable _table = DataBase.fromDB($"select [name] from [categories]");
            CBCategory.Items.Clear();
            CBCategory.Items.Add("Новая категория");
            for (int i = 0; i < _table.Rows.Count; i++)
            {
                CBCategory.Items.Add(_table.Rows[i][0]);
            }
            CBCategory.SelectedIndex = 0;
        }

        private void TextBoxOnlyNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8 && number != 44)
                e.Handled = true;
        }
        private void TBCount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
                e.Handled = true;
        }

        private void CBDiscount_CheckedChanged(object sender, EventArgs e)
        {
            if (CBDiscount.Checked)
            {
                TBDiscount.Enabled = true;
                IsHaveDiscount = true;
            }
            else
            {
                TBDiscount.Enabled = false;
                IsHaveDiscount = false;
            }
        }

        private void CBCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CBCategory.Text == "Новая категория")
            {
                IsCategoryNew = true;
                TBNewCategory.Enabled = true;
            }
            else
            {
                IsCategoryNew = false;
                TBNewCategory.Enabled = false;
            }
        }

        private void PBImg_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Файлы картинок|*.jpg;*.jpeg;*.png;";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    IsHaveImg = true;
                    PBImg.BackgroundImage = Image.FromFile(ofd.FileName);
                    image_bytes = File.ReadAllBytes(ofd.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BTSave_Click(object sender, EventArgs e)
        {
            if (TBName.Text != "" & TBPrice.Text != "" & TBCount.Text != "")
            {
                DataTable IsGoodsAlredyAdded = DataBase.fromDB($"select * from [products] where [name] = '{TBName.Text}'");
                if (IsGoodsAlredyAdded.Rows.Count == 0)
                {
                    DataTable categoryId = new DataTable();
                    if (IsCategoryNew == false)
                    {
                        categoryId = DataBase.fromDB($"select [id] from [categories] where [name] = '{CBCategory.Text}'");
                    }
                    if (IsCategoryNew == true)
                    {
                        if (TBNewCategory.Text != "")
                        {
                            DataBase.toDB($"insert into [categories]([name]) values ('{TBNewCategory.Text}')");
                            categoryId = DataBase.fromDB($"select [id] from [categories] where [name] = '{TBNewCategory.Text}'");
                        }
                        else
                        {
                            MessageBox.Show("Заполните обязательные поля", "Ошибка создания", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }

                    if (TBDesc.Text == "") TBDesc.Text = "Описание товара ещё не добавлено";
                    DataBase.toDB($"insert into[products]([name], [description], [price], [count]) " +
                    $"values('{TBName.Text}', '{TBDesc.Text}', '{TBPrice.Text}', '{TBCount.Text}')");
                    DataTable productId = DataBase.fromDB($"select [id] from [products] where [name] = '{TBName.Text}'");
                    DataBase.toDB($"update [products] set [categoria] = '{categoryId.Rows[0]["id"]}' where [id] = '{productId.Rows[0]["id"]}'");

                    if (IsHaveDiscount == true)
                        DataBase.toDB($"update [products] set [discount] = '{TBDiscount.Text}' where [id] = '{productId.Rows[0]["id"]}'");

                    if (IsHaveImg == true)
                        DataBase.ImageToDB($"Update [products] set [img] = @ImageData where id = '{productId.Rows[0]["id"]}'", image_bytes);

                    MessageBox.Show("Добавлен новый товар","Статус");
                    DialogResult = DialogResult.Yes;
                }
                else
                    MessageBox.Show("Товар с таким наименование уже существует", "Ошибка добавления", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
                MessageBox.Show("Заполните обязательные поля", "Ошибка создания", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void BTBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
