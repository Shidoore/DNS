﻿namespace DNS.Forms
{
    partial class AddNewGoods
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewGoods));
            this.BTBack = new System.Windows.Forms.Label();
            this.BTSave = new System.Windows.Forms.Label();
            this.TBDiscount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TBDesc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TBName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CBCategory = new System.Windows.Forms.ComboBox();
            this.LNewCategory = new System.Windows.Forms.Label();
            this.TBNewCategory = new System.Windows.Forms.TextBox();
            this.TBPrice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TBCount = new System.Windows.Forms.TextBox();
            this.CBDiscount = new System.Windows.Forms.CheckBox();
            this.PBImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).BeginInit();
            this.SuspendLayout();
            // 
            // BTBack
            // 
            this.BTBack.AutoSize = true;
            this.BTBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTBack.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTBack.Location = new System.Drawing.Point(27, 476);
            this.BTBack.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTBack.Name = "BTBack";
            this.BTBack.Size = new System.Drawing.Size(59, 23);
            this.BTBack.TabIndex = 30;
            this.BTBack.Tag = "7";
            this.BTBack.Text = "Назад";
            this.BTBack.Click += new System.EventHandler(this.BTBack_Click);
            // 
            // BTSave
            // 
            this.BTSave.AutoSize = true;
            this.BTSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BTSave.ForeColor = System.Drawing.Color.DarkOrange;
            this.BTSave.Location = new System.Drawing.Point(445, 476);
            this.BTSave.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BTSave.Name = "BTSave";
            this.BTSave.Size = new System.Drawing.Size(86, 23);
            this.BTSave.TabIndex = 28;
            this.BTSave.Tag = "8";
            this.BTSave.Text = "Добавить";
            this.BTSave.Click += new System.EventHandler(this.BTSave_Click);
            // 
            // TBDiscount
            // 
            this.TBDiscount.Enabled = false;
            this.TBDiscount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBDiscount.Location = new System.Drawing.Point(31, 358);
            this.TBDiscount.MaxLength = 20;
            this.TBDiscount.Name = "TBDiscount";
            this.TBDiscount.Size = new System.Drawing.Size(201, 31);
            this.TBDiscount.TabIndex = 4;
            this.TBDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxOnlyNumeric_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14F);
            this.label5.Location = new System.Drawing.Point(27, 256);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(205, 23);
            this.label5.TabIndex = 25;
            this.label5.Text = "Изначальная стоимость:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14F);
            this.label4.Location = new System.Drawing.Point(270, 332);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 23);
            this.label4.TabIndex = 24;
            this.label4.Text = "Категория:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14F);
            this.label3.Location = new System.Drawing.Point(161, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 23);
            this.label3.TabIndex = 22;
            this.label3.Text = "Описание:";
            // 
            // TBDesc
            // 
            this.TBDesc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBDesc.Location = new System.Drawing.Point(165, 140);
            this.TBDesc.MaxLength = 350;
            this.TBDesc.Multiline = true;
            this.TBDesc.Name = "TBDesc";
            this.TBDesc.Size = new System.Drawing.Size(366, 104);
            this.TBDesc.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14F);
            this.label2.Location = new System.Drawing.Point(25, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 23);
            this.label2.TabIndex = 20;
            this.label2.Text = "Наименование:";
            // 
            // TBName
            // 
            this.TBName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBName.Location = new System.Drawing.Point(165, 75);
            this.TBName.MaxLength = 100;
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(366, 31);
            this.TBName.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(26, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 29);
            this.label1.TabIndex = 18;
            this.label1.Text = "Добавление нового товара";
            // 
            // CBCategory
            // 
            this.CBCategory.BackColor = System.Drawing.Color.White;
            this.CBCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBCategory.FormattingEnabled = true;
            this.CBCategory.Items.AddRange(new object[] {
            "Новая категория"});
            this.CBCategory.Location = new System.Drawing.Point(274, 358);
            this.CBCategory.Name = "CBCategory";
            this.CBCategory.Size = new System.Drawing.Size(257, 31);
            this.CBCategory.TabIndex = 5;
            this.CBCategory.SelectedIndexChanged += new System.EventHandler(this.CBCategory_SelectedIndexChanged);
            // 
            // LNewCategory
            // 
            this.LNewCategory.AutoSize = true;
            this.LNewCategory.Font = new System.Drawing.Font("Calibri", 14F);
            this.LNewCategory.Location = new System.Drawing.Point(27, 401);
            this.LNewCategory.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LNewCategory.Name = "LNewCategory";
            this.LNewCategory.Size = new System.Drawing.Size(176, 23);
            this.LNewCategory.TabIndex = 35;
            this.LNewCategory.Text = "Название категории:";
            // 
            // TBNewCategory
            // 
            this.TBNewCategory.Enabled = false;
            this.TBNewCategory.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBNewCategory.Location = new System.Drawing.Point(27, 427);
            this.TBNewCategory.MaxLength = 100;
            this.TBNewCategory.Name = "TBNewCategory";
            this.TBNewCategory.Size = new System.Drawing.Size(500, 31);
            this.TBNewCategory.TabIndex = 6;
            // 
            // TBPrice
            // 
            this.TBPrice.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBPrice.Location = new System.Drawing.Point(31, 282);
            this.TBPrice.MaxLength = 20;
            this.TBPrice.Name = "TBPrice";
            this.TBPrice.Size = new System.Drawing.Size(201, 31);
            this.TBPrice.TabIndex = 2;
            this.TBPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxOnlyNumeric_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14F);
            this.label7.Location = new System.Drawing.Point(270, 256);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 23);
            this.label7.TabIndex = 37;
            this.label7.Text = "Количество:";
            // 
            // TBCount
            // 
            this.TBCount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TBCount.Location = new System.Drawing.Point(274, 282);
            this.TBCount.MaxLength = 20;
            this.TBCount.Name = "TBCount";
            this.TBCount.Size = new System.Drawing.Size(257, 31);
            this.TBCount.TabIndex = 3;
            this.TBCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TBCount_KeyPress);
            // 
            // CBDiscount
            // 
            this.CBDiscount.AutoSize = true;
            this.CBDiscount.Location = new System.Drawing.Point(31, 325);
            this.CBDiscount.Name = "CBDiscount";
            this.CBDiscount.Size = new System.Drawing.Size(202, 27);
            this.CBDiscount.TabIndex = 39;
            this.CBDiscount.Text = "Скидочная стоимость";
            this.CBDiscount.UseVisualStyleBackColor = true;
            this.CBDiscount.CheckedChanged += new System.EventHandler(this.CBDiscount_CheckedChanged);
            // 
            // PBImg
            // 
            this.PBImg.BackColor = System.Drawing.Color.Gainsboro;
            this.PBImg.BackgroundImage = global::DNS.Properties.Resources.NoPhoto;
            this.PBImg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PBImg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBImg.Image = global::DNS.Properties.Resources.PhotoChange_;
            this.PBImg.Location = new System.Drawing.Point(29, 114);
            this.PBImg.Name = "PBImg";
            this.PBImg.Size = new System.Drawing.Size(130, 130);
            this.PBImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PBImg.TabIndex = 40;
            this.PBImg.TabStop = false;
            this.PBImg.Click += new System.EventHandler(this.PBImg_Click);
            // 
            // AddNewGoods
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(561, 522);
            this.Controls.Add(this.PBImg);
            this.Controls.Add(this.CBDiscount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TBCount);
            this.Controls.Add(this.TBPrice);
            this.Controls.Add(this.TBNewCategory);
            this.Controls.Add(this.LNewCategory);
            this.Controls.Add(this.CBCategory);
            this.Controls.Add(this.BTBack);
            this.Controls.Add(this.BTSave);
            this.Controls.Add(this.TBDiscount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TBDesc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "AddNewGoods";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddNewGoods";
            this.Load += new System.EventHandler(this.AddNewGoods_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PBImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label BTBack;
        private System.Windows.Forms.Label BTSave;
        private System.Windows.Forms.TextBox TBDiscount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBCategory;
        private System.Windows.Forms.Label LNewCategory;
        private System.Windows.Forms.TextBox TBNewCategory;
        private System.Windows.Forms.TextBox TBPrice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBCount;
        private System.Windows.Forms.CheckBox CBDiscount;
        private System.Windows.Forms.PictureBox PBImg;
    }
}