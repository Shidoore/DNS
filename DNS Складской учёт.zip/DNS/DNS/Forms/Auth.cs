﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNS
{
    public partial class Auth : Form
    {
        public Auth()
        {
            InitializeComponent();
        }

        #region visual

        private void TextBox_Enter(object sender, EventArgs e)
        {
            string _textbox = (((TextBox)sender).Tag).ToString();
            switch (_textbox)
            {
                case "Логин":
                    if (TBLogin.Text == "Логин")
                    { TBLogin.Text = null; TBLogin.ForeColor = Color.Black; }
                    break;
                case "Пароль":
                    if (TBPassword.Text == "Пароль")
                    { 
                        TBPassword.Text = null; 
                        TBPassword.ForeColor = Color.Black;
                        TBPassword.UseSystemPasswordChar = true;
                    }
                    break;
            }
        }

        private void TextBox_Leave(object sender, EventArgs e)
        {
            string _textbox = (((TextBox)sender).Tag).ToString();
            switch (_textbox)
            {
                case "Логин":
                    if (TBLogin.Text == "")
                    { TBLogin.Text = "Логин"; TBLogin.ForeColor = Color.Gray; }
                    break;
                case "Пароль":
                    if (TBPassword.Text == "")
                    { 
                        TBPassword.Text = "Пароль";
                        TBPassword.ForeColor = Color.Gray;
                        TBPassword.UseSystemPasswordChar = false;
                    }
                    break;
            }
        }

        private void Button_Enter(object sender, EventArgs e)
        {
            var _button = (Button)sender;
            _button.BackColor = Color.Orange;
        }

        private void Button_Leave(object sender, EventArgs e)
        {
            var _button = (Button)sender;
            _button.BackColor = Color.DarkOrange;
        }


        #endregion

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                DoAuth();
        }

        private void BTLogin_Click(object sender, EventArgs e)
        {
            DoAuth();
        }

        private void DoAuth()
        {
            if (TBLogin.Text != "" && TBPassword.Text != "")
            {
                DataTable _table = DataBase.fromDB($"select [id],[role],[login],[password] from [users] " +
                $"where [login] ='{TBLogin.Text}' and [password]='{TBPassword.Text}'");

                if (_table.Rows.Count == 1)
                {
                    string _Role = _table.Rows[0][1].ToString();
                    string _id = _table.Rows[0][0].ToString();

                    MainForm _mainForm = new MainForm();
                    _mainForm.userId = _id;
                    switch (_Role)
                    {
                        case "1":
                            this.Hide();
                            _mainForm.userRole = "Администратор";
                            _mainForm.Show();
                            break;
                        default:
                            this.Hide();
                            _mainForm.userRole = "Пользователь";
                            _mainForm.Show();
                            break;
                    }
                }
                else
                    MessageBox.Show("Неверный логин или пароль", "Вход в аккаунт не выполнен", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Все поля должны быть заполнены");
        }

        private void TBLogin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
